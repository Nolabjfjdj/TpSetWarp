package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.util.DimensionUtil;
import com.nolanlabanane.tpsetwarp.util.Messages;
import com.nolanlabanane.tpsetwarp.warp.Warp;
import com.nolanlabanane.tpsetwarp.warp.WarpManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

/**
 * /setwarp <nom>
 * Réservé aux opérateurs (niveau de permission 2, système vanilla).
 */
public final class SetWarpCommand {

    private SetWarpCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(WarpManager warpManager, LanguageManager languageManager) {
        return class_2170.method_9247("setwarp")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9244("nom", StringArgumentType.word())
                        .executes(ctx -> execute(ctx, warpManager, languageManager)));
    }

    private static int execute(CommandContext<class_2168> ctx, WarpManager warpManager, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();
        Language lang = languageManager.resolve(source);

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(Messages.playerOnlyCommand(lang));
            return 0;
        }

        String name = StringArgumentType.getString(ctx, "nom");

        if (warpManager.exists(name)) {
            source.method_9213(Messages.warpAlreadyExists(lang, name));
            return 0;
        }

        Warp warp = new Warp(
                name,
                player.method_5667(),
                player.method_7334().getName(),
                player.method_23317(),
                player.method_23318(),
                player.method_23321(),
                player.method_36454(),
                player.method_36455(),
                DimensionUtil.toDimensionId(player.method_51469()),
                System.currentTimeMillis()
        );

        warpManager.create(warp);
        source.method_9226(() -> Messages.warpCreated(lang, name), true);
        return 1;
    }
}

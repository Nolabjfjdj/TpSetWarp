package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.util.Messages;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

/**
 * /warplang <fr|en>
 * Change la langue des messages du mod pour le joueur qui exécute la commande.
 * Accessible à tous les joueurs (niveau de permission 0, système vanilla) : chacun
 * choisit sa propre langue, indépendamment des autres.
 */
public final class LanguageCommand {

    private LanguageCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(LanguageManager languageManager) {
        return class_2170.method_9247("warplang")
                .requires(source -> source.method_9259(0))
                .then(class_2170.method_9244("langue", StringArgumentType.word())
                        .executes(ctx -> execute(ctx, languageManager)));
    }

    private static int execute(CommandContext<class_2168> ctx, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(Messages.playerOnlyCommand(languageManager.resolve(source)));
            return 0;
        }

        String code = StringArgumentType.getString(ctx, "langue");
        Language newLang = Language.fromCode(code);

        languageManager.set(player.method_5667(), newLang);
        source.method_9226(() -> Messages.languageChanged(newLang), false);
        return 1;
    }
}

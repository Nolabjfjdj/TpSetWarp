package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.util.Messages;
import com.nolanlabanane.tpsetwarp.warp.Warp;
import com.nolanlabanane.tpsetwarp.warp.WarpManager;
import java.util.Collection;
import java.util.stream.Collectors;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/**
 * /warps
 * Affiche la liste de tous les warps. Accessible à tous les joueurs.
 */
public final class WarpsCommand {

    private WarpsCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(WarpManager warpManager, LanguageManager languageManager) {
        return class_2170.method_9247("warps")
                .requires(source -> source.method_9259(0))
                .executes(ctx -> execute(ctx, warpManager, languageManager));
    }

    private static int execute(CommandContext<class_2168> ctx, WarpManager warpManager, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();
        Language lang = languageManager.resolve(source);
        Collection<Warp> warps = warpManager.getAll();

        if (warps.isEmpty()) {
            source.method_9213(Messages.noWarps(lang));
            return 0;
        }

        source.method_9226(() -> Messages.warpsListHeader(lang, warps.size()), false);

        String names = warps.stream()
                .map(Warp::getName)
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .collect(Collectors.joining(", "));

        source.method_9226(() -> class_2561.method_43470("§7" + names), false);
        return warps.size();
    }
}

package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.util.Messages;
import com.nolanlabanane.tpsetwarp.warp.Warp;
import com.nolanlabanane.tpsetwarp.warp.WarpManager;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

/**
 * /warpinfo <nom>
 * Affiche les détails d'un warp. Accessible à tous les joueurs (lecture seule).
 */
public final class WarpInfoCommand {

    private WarpInfoCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(WarpManager warpManager, LanguageManager languageManager) {
        return class_2170.method_9247("warpinfo")
                .requires(source -> source.method_9259(0))
                .then(class_2170.method_9244("nom", StringArgumentType.word())
                        .executes(ctx -> execute(ctx, warpManager, languageManager)));
    }

    private static int execute(CommandContext<class_2168> ctx, WarpManager warpManager, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();
        Language lang = languageManager.resolve(source);
        String name = StringArgumentType.getString(ctx, "nom");
        Optional<Warp> optWarp = warpManager.get(name);

        if (optWarp.isEmpty()) {
            source.method_9213(Messages.warpNotFound(lang, name));
            return 0;
        }

        Warp warp = optWarp.get();
        source.method_9226(() -> Messages.warpInfoHeader(lang, warp.getName()), false);
        source.method_9226(() -> Messages.warpInfoDimension(lang, warp.getDimension()), false);
        source.method_9226(() -> Messages.warpInfoCoordinates(lang, warp.getX(), warp.getY(), warp.getZ()), false);
        source.method_9226(() -> Messages.warpInfoCreator(lang, warp.getCreatorName()), false);
        source.method_9226(() -> Messages.warpInfoCreatedOn(lang, warp.getFormattedCreationDate()), false);
        return 1;
    }
}

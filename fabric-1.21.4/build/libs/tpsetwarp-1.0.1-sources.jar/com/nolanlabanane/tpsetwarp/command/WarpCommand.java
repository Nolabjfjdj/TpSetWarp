package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.teleport.TeleportHandler;
import com.nolanlabanane.tpsetwarp.util.Messages;
import com.nolanlabanane.tpsetwarp.warp.Warp;
import com.nolanlabanane.tpsetwarp.warp.WarpManager;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

/**
 * /warp <nom>
 * Accessible à tous les joueurs (niveau de permission 0, système vanilla).
 */
public final class WarpCommand {

    private WarpCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(WarpManager warpManager, LanguageManager languageManager) {
        return class_2170.method_9247("warp")
                .requires(source -> source.method_9259(0))
                .then(class_2170.method_9244("nom", StringArgumentType.word())
                        .executes(ctx -> execute(ctx, warpManager, languageManager)));
    }

    private static int execute(CommandContext<class_2168> ctx, WarpManager warpManager, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();
        Language lang = languageManager.resolve(source);

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(Messages.playerOnlyCommand(lang));
            return 0;
        }

        String name = StringArgumentType.getString(ctx, "nom");
        Optional<Warp> warp = warpManager.get(name);

        if (warp.isEmpty()) {
            source.method_9213(Messages.warpNotFound(lang, name));
            return 0;
        }

        TeleportHandler.Result result = TeleportHandler.teleport(player, warp.get());

        if (result == TeleportHandler.Result.DIMENSION_NOT_FOUND) {
            source.method_9213(Messages.dimensionUnavailable(lang));
            return 0;
        }

        source.method_9226(() -> Messages.teleporting(lang, name), false);
        return 1;
    }
}

package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.util.Messages;
import com.nolanlabanane.tpsetwarp.warp.WarpManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

/**
 * /renamewarp <ancien> <nouveau>
 * Réservé aux opérateurs.
 */
public final class RenameWarpCommand {

    private RenameWarpCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(WarpManager warpManager, LanguageManager languageManager) {
        return class_2170.method_9247("renamewarp")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9244("ancien", StringArgumentType.word())
                        .then(class_2170.method_9244("nouveau", StringArgumentType.word())
                                .executes(ctx -> execute(ctx, warpManager, languageManager))));
    }

    private static int execute(CommandContext<class_2168> ctx, WarpManager warpManager, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();
        Language lang = languageManager.resolve(source);
        String oldName = StringArgumentType.getString(ctx, "ancien");
        String newName = StringArgumentType.getString(ctx, "nouveau");

        if (!warpManager.exists(oldName)) {
            source.method_9213(Messages.warpNotFound(lang, oldName));
            return 0;
        }

        if (warpManager.exists(newName)) {
            source.method_9213(Messages.warpAlreadyExists(lang, newName));
            return 0;
        }

        warpManager.rename(oldName, newName);
        source.method_9226(() -> Messages.warpRenamed(lang, oldName, newName), true);
        return 1;
    }
}

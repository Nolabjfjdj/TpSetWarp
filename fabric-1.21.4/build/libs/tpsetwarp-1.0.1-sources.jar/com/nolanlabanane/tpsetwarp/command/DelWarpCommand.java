package com.nolanlabanane.tpsetwarp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.nolanlabanane.tpsetwarp.lang.Language;
import com.nolanlabanane.tpsetwarp.lang.LanguageManager;
import com.nolanlabanane.tpsetwarp.util.Messages;
import com.nolanlabanane.tpsetwarp.warp.WarpManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

/**
 * /delwarp <nom>
 * Réservé aux opérateurs.
 */
public final class DelWarpCommand {

    private DelWarpCommand() {
    }

    public static LiteralArgumentBuilder<class_2168> build(WarpManager warpManager, LanguageManager languageManager) {
        return class_2170.method_9247("delwarp")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9244("nom", StringArgumentType.word())
                        .executes(ctx -> execute(ctx, warpManager, languageManager)));
    }

    private static int execute(CommandContext<class_2168> ctx, WarpManager warpManager, LanguageManager languageManager) {
        class_2168 source = ctx.getSource();
        Language lang = languageManager.resolve(source);
        String name = StringArgumentType.getString(ctx, "nom");

        if (!warpManager.delete(name)) {
            source.method_9213(Messages.warpNotFound(lang, name));
            return 0;
        }

        source.method_9226(() -> Messages.warpDeleted(lang, name), true);
        return 1;
    }
}

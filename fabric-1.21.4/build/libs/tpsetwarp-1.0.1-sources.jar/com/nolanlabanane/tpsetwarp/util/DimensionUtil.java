package com.nolanlabanane.tpsetwarp.util;

import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

/**
 * Petits helpers autour des dimensions.
 * Regroupés ici pour éviter de dupliquer la logique de parsing/résolution
 * dans plusieurs classes.
 */
public final class DimensionUtil {

    private DimensionUtil() {
    }

    /** Convertit un ServerLevel en identifiant texte "namespace:path". */
    public static String toDimensionId(class_3218 level) {
        return level.method_27983().method_29177().toString();
    }

    /**
     * Résout un identifiant de dimension texte ("minecraft:overworld", "minecraft:the_nether", ...)
     * vers le ServerLevel correspondant.
     * Retourne null si la dimension n'existe pas (mod désinstallé, dimension custom absente, etc.).
     */
    public static class_3218 resolveLevel(MinecraftServer server, String dimensionId) {
        class_2960 location = class_2960.method_12829(dimensionId);
        if (location == null) {
            return null;
        }
        class_5321<net.minecraft.class_1937> key =
                class_5321.method_29179(class_7924.field_41223, location);
        return server.method_3847(key);
    }
}

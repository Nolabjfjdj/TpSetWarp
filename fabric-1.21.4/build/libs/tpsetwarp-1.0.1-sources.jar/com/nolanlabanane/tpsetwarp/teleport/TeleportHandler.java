package com.nolanlabanane.tpsetwarp.teleport;

import com.nolanlabanane.tpsetwarp.util.DimensionUtil;
import com.nolanlabanane.tpsetwarp.warp.Warp;
import java.util.Set;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Toute la logique de téléportation est isolée ici.
 *
 * IMPORTANT POUR LE PORTAGE : si l'API Minecraft/Forge change la signature
 * de ServerPlayer#teleportTo entre deux versions, c'est LA SEULE classe
 * à modifier dans tout le mod.
 */
public final class TeleportHandler {

    private TeleportHandler() {
    }

    /**
     * Résultat d'une tentative de téléportation.
     */
    public enum Result {
        SUCCESS,
        DIMENSION_NOT_FOUND
    }

    /**
     * Téléporte un joueur vers un warp, y compris entre dimensions.
     * Conserve l'orientation (yaw/pitch) enregistrée dans le warp.
     */
    public static Result teleport(class_3222 player, Warp warp) {
        class_3218 targetLevel = DimensionUtil.resolveLevel(player.method_5682(), warp.getDimension());
        if (targetLevel == null) {
            return Result.DIMENSION_NOT_FOUND;
        }

        // Stoppe toute chute/élan en cours pour éviter les téléportations "glissées".
        player.field_6017 = 0;

        // teleportTo gère nativement le changement de dimension (ServerLevel identique ou non).
        // Depuis la 1.21.2, la signature demande en plus :
        //  - un Set<Relative> : vide ici, car warp.getX/Y/Z/Yaw/Pitch sont des coordonnées
        //    ABSOLUES (rien de relatif façon "~ ~ ~" façon commande /tp).
        //  - un boolean final (recentre la caméra du joueur sur la nouvelle position,
        //    comportement standard attendu pour une téléportation "franche" type warp).
        player.method_48105(
                targetLevel,
                warp.getX(),
                warp.getY(),
                warp.getZ(),
                Set.of(),
                warp.getYaw(),
                warp.getPitch(),
                true
        );

        return Result.SUCCESS;
    }
}
